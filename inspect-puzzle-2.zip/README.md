# Inspecteerbare Hint Puzzel – Deel 2

Inspecteer de pagina (rechter muisklik → Inspecteren) en zoek het verborgen wachtwoord.

Wachtwoord = 'school' gespiegeld → invoeren → je krijgt een MD5-hash.

Gebruik die als toegangscode voor de volgende puzzel.