function md5cycle(x, k) {
  var a = x[0], b = x[1], c = x[2], d = x[3];

  a = ff(a, b, c, d, k[0], 7, -680876936);
  d = ff(d, a, b, c, k[1], 12, -389564586);
  c = ff(c, d, a, b, k[2], 17,  606105819);
  d = ff(d, c, a, b, k[3], 22, -1044525330);
  // [Truncated for brevity, this is a placeholder.]
  return [a, b, c, d];
}
function md5(s) {
  function cmn(q, a, b, x, s, t) {
    a = add32(add32(a, q), add32(x, t));
    return add32((a << s) | (a >>> (32 - s)), b);
  }
  function ff(a, b, c, d, x, s, t) {
    return cmn((b & c) | ((~b) & d), a, b, x, s, t);
  }
  // simplified version, use blueimp-md5 for production
  function md51(s) {
    txt = '';
    var n = s.length,
      state = [1732584193, -271733879, -1732584194, 271733878],
      i;
    for (i=64; i<=s.length; i+=64) {
      md5cycle(state, md5blk(s.substring(i-64, i)));
    }
    return state;
  }
  function rhex(n) {
    var s = '', j = 0;
    for(; j < 4; j++)
      s += ('0' + ((n >> (j * 8 + 4)) & 0x0F).toString(16)).slice(-2) +
           ('0' + ((n >> (j * 8)) & 0x0F).toString(16)).slice(-2);
    return s;
  }
  return rhex(md51(s)[0]);
}